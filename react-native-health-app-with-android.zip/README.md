# React Native Health App
A mobile app for health registration using React Native.